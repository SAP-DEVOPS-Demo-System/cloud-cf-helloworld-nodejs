Copyright (c) 2017 SAP SE or an SAP affiliate company. All rights reserved.

